[![Build Status](https://travis-ci.org/kanla/kanla.png?branch=master)](https://travis-ci.org/kanla/kanla)

You can find more information at http://kanla.zekjur.net/
